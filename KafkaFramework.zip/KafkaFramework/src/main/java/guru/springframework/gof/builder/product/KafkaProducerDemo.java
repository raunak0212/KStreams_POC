package guru.springframework.gof.builder.product;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

public class KafkaProducerDemo {

    public static void main(String[] args) throws NullPointerException, InterruptedException, ExecutionException, IOException {
        final String topicName = "test-topic";

        final SimpleKafkaProducer simpleKafkaProducer = SimpleKafkaProducer.getInstance();
        System.out.println("Please Enter value");
        
        simpleKafkaProducer.getJsonData(topicName);
    }
}
