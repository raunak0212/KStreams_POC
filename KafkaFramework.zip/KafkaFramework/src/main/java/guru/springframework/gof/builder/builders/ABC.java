package guru.springframework.gof.builder.builders;
import java.util.Scanner;

import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

public class ABC {
public static void main(String []args) {
	getJsonData();
}

static String getJsonData() {
	// TODO Auto-generated method stub

    String JSONmsg;
    Scanner scanner = new Scanner(System.in);
    System.out.println("Feed me with numbers!");

    while((JSONmsg = scanner.next())!=null) {
    	
    	/*try{
    		JsonParser parser = new JsonParser();
    		parser.parse(JSONmsg);
    		} 
    		catch(JsonSyntaxException jse){
    		System.out.println("Not a valid Json String:"+jse.getMessage());
    		}*/
       
    }
	return JSONmsg;

   /* {
        System.out.println("");
        System.exit(1);
    }*/


}
}