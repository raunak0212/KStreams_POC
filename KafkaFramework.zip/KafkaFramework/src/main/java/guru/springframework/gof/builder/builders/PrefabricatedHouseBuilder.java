package guru.springframework.gof.builder.builders;

import java.util.Properties;

import guru.springframework.gof.builder.product.House;

public class PrefabricatedHouseBuilder implements HouseBuilder{
    private House house;

    public PrefabricatedHouseBuilder() {
        this.house = new House();
    }
   
    
    public House getHouse() {
        System.out.println("PrefabricatedHouseBuilder: Prefabricated house complete...");
        return this.house;
    }
    
	public void createProducer(String propertyFilePath) {
		// TODO Auto-generated method stub
		
		
		
	}
	
	public void createConsumer(String propertyFilePath) {
		// TODO Auto-generated method stub
		
	}
}