package guru.springframework.gof.builder.builders;

import java.io.IOException;
import java.util.Properties;

import guru.springframework.gof.builder.product.House;

public interface HouseBuilder {
    void createProducer(String propertyFilePath) throws IOException;
    void createConsumer(String propertyFilePath);

    House getHouse();
}