package guru.springframework.gof.builder.builders;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

import org.json.simple.parser.ParseException;

public class Main {

	public static void main(String[] args) throws NullPointerException, InterruptedException, ExecutionException, IOException, ParseException {
		// TODO Auto-generated method stub
		EDFProducer eDFProducer=new EDFProducer();
		String schema =
	            "{" +
	            "   \"type\" : \"record\"," +
	            "   \"name\" : \"Acme\"," +
	            "   \"fields\" : [{ \"name\" : \"username\", \"type\" : \"string\" }]" +
	            "}";
		

	    String topicName="testtopicLOL";
	//	eDFProducer.send(schema, json, topicName);
	    System.out.println(  eDFProducer.getJsonData(schema, topicName));
	  
	// {"username":"George Flyodd"}	
	 // {"username":"Tera tera Tera suroor"}	

	}

}
