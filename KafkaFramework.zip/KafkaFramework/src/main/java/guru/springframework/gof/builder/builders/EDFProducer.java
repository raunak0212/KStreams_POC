package guru.springframework.gof.builder.builders;

import java.io.IOException;
import java.io.Serializable;
import java.util.Properties;
import java.util.Scanner;
import java.util.concurrent.ExecutionException;

import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import io.confluent.kafka.serializers.KafkaAvroSerializer;
import tech.allegro.schema.json2avro.converter.AvroConversionException;
import tech.allegro.schema.json2avro.converter.JsonAvroConverter;
import org.apache.avro.generic.GenericData;
import org.apache.avro.Schema;

public class EDFProducer implements Serializable{
	
	 String  JSONmsg;
	private KafkaProducer<String, GenericRecord> producer;
	
	private static Logger LOGGER = Logger.getLogger(EDFProducer.class);
	
	public EDFProducer(){
		super();
		LOGGER.info("Created Instance of EDFProducer......");
		
	}
	
	/*public EDFProducer(String customLoggerName ,String logLevel){
		super();
		if(customLoggerName!=null && !customLoggerName.isEmpty()){
			LOGGER=Logger.getLogger(customLoggerName);
			
		} else{
			LOGGER=Logger.getLogger(EDFProducer.class);
		}
		setloglevel(logLevel,LOGGER);
		LOGGER.info("Created Instance pf EDFproducer using customLoggerName"+ customLoggerName +"with logLevel: "
				+ LOGGER.getLevel().toString());
				
	}*/
	
	public Properties loadEDFProducerProperties() throws IOException{
		
		LOGGER.info("Loading EDFProducer Properties");
		Properties properties= new Properties();
		/*props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class.getName());
		props.setProperty("schema.registry.url", "http://127.0.0.1:8081");*/
		    properties.setProperty("bootstrap.servers", "127.0.0.1:9092");
	        properties.setProperty("acks", "all");
	        properties.setProperty("retries", "10");
	        // avro part
	        properties.setProperty("key.serializer", StringSerializer.class.getName());
	        properties.setProperty("value.serializer", KafkaAvroSerializer.class.getName());
	        properties.setProperty("schema.registry.url", "http://127.0.0.1:8081");

		
		
		/*Add some more properties*/
		producer= new KafkaProducer<String , GenericRecord>(properties);
		LOGGER.info("Loaded EDFProducer Properties");
		return properties;
		
	}

	
	
	public void send (String avroSchema,  String msgAsJson, String topicName) 
			throws InterruptedException,NullPointerException,ExecutionException,IOException{
		if(topicName==null){
			LOGGER.error("Topic is Null");
			throw new NullPointerException("No valid topics found");
			
		}
		
		GenericRecord val;
		val=convertJsonToAvro(avroSchema,msgAsJson);
		System.out.println(val.toString());
		
		producer = new KafkaProducer<String, GenericRecord>(loadEDFProducerProperties());
		ProducerRecord<String,GenericRecord> record= new ProducerRecord<String,GenericRecord>(topicName,val);
		
		producer.send(record, new Callback() {
	            @Override
	            public void onCompletion(RecordMetadata metadata, Exception exception) {
	                if (exception == null) {
	                    System.out.println(metadata);
	                } else {
	                    exception.printStackTrace();
	                }
	            }
	        });
		 producer.flush();
		 
		}
		 
	
	private GenericRecord convertJsonToAvro(String avroSchema, String msgAsJson) {
		// TODO Auto-generated method stub
		JsonAvroConverter converter = new JsonAvroConverter();

		// conversion to binary Avro
		byte[] avro = converter.convertToAvro(msgAsJson.getBytes(), avroSchema);

		// conversion to GenericData.Record
		GenericData.Record record = converter.convertToGenericDataRecord(msgAsJson.getBytes(), new Schema.Parser().parse(avroSchema));

		// conversion from binary Avro to JSON
		byte[] binaryJson = converter.convertToJson(avro, avroSchema);
		return record;
	}

	String getJsonData(String avroSchema,  String topicName) throws NullPointerException, InterruptedException, ExecutionException, IOException {
		// TODO Auto-generated method stub
       String JSONmsg;
       while(true){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Feed me with numbers!");
        JSONmsg = scanner.nextLine();
        if(JSONmsg==null){
        	System.out.println("Enter valid JSON");
        	throw new NullPointerException();
        	
        }
        System.out.println(JSONmsg);
        JSONParser parser = new JSONParser(); 
	    JSONObject json1;
		try {
			json1 = (JSONObject) parser.parse(JSONmsg);
			System.out.println(json1);
	        send(avroSchema, json1.toJSONString(), topicName);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			continue;
		}
	    

        
       }
    
	}
	
	

}
