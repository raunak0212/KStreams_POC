package com.bmo.ET.kafka.apps.v1;

import com.example.avro.RawClass;
import com.example.avro.TransformedClass;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import io.confluent.kafka.serializers.AbstractKafkaAvroSerDeConfig;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import io.confluent.kafka.streams.serdes.avro.SpecificAvroSerde;
import org.apache.commons.codec.binary.Base64;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Printed;
import org.apache.kafka.streams.kstream.Produced;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;

public class KafkaAvroJavaStreamMultipleTopics {
	
	public Properties buildStreamsProperties() {
	    Properties props = new Properties();

	    props.put(StreamsConfig.APPLICATION_ID_CONFIG, "streams-multipleTopics");
	    props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
	    props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
	    props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
	    props.put(AbstractKafkaAvroSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, "http://127.0.0.1:8081");
	    props.put(StreamsConfig.CACHE_MAX_BYTES_BUFFERING_CONFIG, 0);

	    return props;
	  }
	
	
	public static Properties readpropertyFile() throws IOException {
		InputStream input = new FileInputStream("C:\\Users\\ravir\\OneDrive\\Desktop\\kafka-avro-course\\kafka-avro-v1\\src\\main\\resources\\email.properties");
		Properties prop = new Properties();
        prop.load(input);
        
	    return prop;
	  }
	
	  @SuppressWarnings("unused")
	private SpecificAvroSerde<RawClass> rawClassSerde() {
		    final SpecificAvroSerde<RawClass> serde = new SpecificAvroSerde<>();
			Map<String, String> config = new HashMap<>();
			config.put(AbstractKafkaAvroSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, "http://127.0.0.1:8081");
			serde.configure(config, false);
			return serde;
			  }
		

	 @SuppressWarnings("unused")
	private SpecificAvroSerde<TransformedClass> transformedClassSerde() {
			final SpecificAvroSerde<TransformedClass> serde = new SpecificAvroSerde<>();
			Map<String, String> config = new HashMap<>();
			config.put(AbstractKafkaAvroSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, "http://127.0.0.1:8081");
			serde.configure(config, false);
			return serde;
				  }
	

	 public Topology buildTopology() throws IOException
              {
                  final StreamsBuilder builder = new StreamsBuilder();

                  final String inputTopic1 = "input_topic1";
                  final String inputTopic2 = "input_topic2";
                  final String outputTopic = "output.topic.name";
                  
                  List<String> topics=Arrays.asList(inputTopic1,inputTopic2);
                  
                  KStream<String, String> inputStream = builder.stream("input_topic4",Consumed.with(Serdes.String(), Serdes.String()));
                //  inputStream.print(Printed.toSysOut());
                  
                  KStream<String, String> TransformedClassStream = inputStream
                          .map((key, value) ->
                          {
							try {
								return new KeyValue<String, String>(key, myFunc(value).toString());
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							return null;
						});
               
                  TransformedClassStream.print(Printed.toSysOut());


                  TransformedClassStream.to("output.topic.transformed2",Produced.with(Serdes.String(), Serdes.String()));
                  
                  return builder.build();
}
	 
	 public static TransformedClass convertRaw(String rawValue) {
	     
		    RawClass p=new RawClass();
	        Gson g = new Gson();
	        return new TransformedClass(p.getName(),p.getIsMarried());
	    	
	    }
	 
	 public static TransformedClass myFunc(String jsonDataSourceString) throws IOException  {
           
	       System.out.println(jsonDataSourceString);
		    //String name="$['name']";
		    String name=readpropertyFile().getProperty("name_field");
		    String married=readpropertyFile().getProperty("married_field");
	       // String jsonpathCreatorNamePath = "$['name']";
	        String jsonpathCreatorNamePath = name;
	        String jsonpathCreatorLocationPath = married;

	        DocumentContext jsonContext = JsonPath.parse(jsonDataSourceString);
	       
	        String jsonpathCreatorName = jsonContext.read(jsonpathCreatorNamePath);
	       // List<String> jsonpathCreatorLocation = jsonContext.read(jsonpathCreatorLocationPath);
	        String jsonpathCreatorLocation = jsonContext.read(jsonpathCreatorLocationPath);

	        System.out.println(jsonpathCreatorName);
	        System.out.println(jsonpathCreatorLocation);
			return new TransformedClass(jsonpathCreatorName,jsonpathCreatorLocation);

	        
	    }

	  
	 @SuppressWarnings("unused")
	private void runRecipe() throws IOException {
		   // Properties envProps = this.loadEnvProperties(configPath);
		   Properties streamProps = this.buildStreamsProperties();

		    Topology topology = this.buildTopology();
		   // this.createTopics(envProps);

		    final KafkaStreams streams = new KafkaStreams(topology, streamProps);
		    final CountDownLatch latch = new CountDownLatch(1);

		    // Attach shutdown handler to catch Control-C.
		    Runtime.getRuntime().addShutdownHook(new Thread("streams-shutdown-hook") {
		      @Override
		      public void run() {
		        streams.close();
		        latch.countDown();
		      }
		    });

		    try {
		      streams.start();
		      latch.await();
		    } catch (Throwable e) {
		      System.exit(1);
		    }
		    System.exit(0);

		  }
		
	
    public static void main(String[] args) throws IOException {
    	
    	new KafkaAvroJavaStreamMultipleTopics().runRecipe();

    }
        
       
    }

