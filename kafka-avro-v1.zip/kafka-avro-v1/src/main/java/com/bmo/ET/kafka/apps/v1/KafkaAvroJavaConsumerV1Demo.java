package com.bmo.ET.kafka.apps.v1;

import com.example.CancelETransfer;
import com.example.Customer;
import com.example.Customer2;
import com.example.Mausam;
import com.example.avro.RawClass;
import com.example.avro.TransformedClass;

import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import io.karengryg.Movie;
import io.karengryg.User;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.util.Collections;
import java.util.Properties;

public class KafkaAvroJavaConsumerV1Demo {

    public static void main(String[] args) {
        Properties properties = new Properties();
        // normal consumer
        properties.setProperty("bootstrap.servers","127.0.0.1:9092");
        properties.put("group.id", "customer-consumer-group-v1");
        properties.put("auto.commit.enable", "false");
        properties.put("auto.offset.reset", "earliest");

        // avro part (deserializer)
        properties.setProperty("key.deserializer", StringDeserializer.class.getName());
        properties.setProperty("value.deserializer", StringDeserializer.class.getName());
        properties.setProperty("schema.registry.url", "http://127.0.0.1:8081");
        properties.setProperty("specific.avro.reader", "true");

        KafkaConsumer<String, String> kafkaConsumer = new KafkaConsumer<>(properties);
      //  KafkaConsumer<String, User> kafkaConsumer1 = new KafkaConsumer<>(properties);
        
       // String topic = "customer-avro1";
        String topic = "output.topic.transformed2";
        kafkaConsumer.subscribe(Collections.singleton(topic));

        System.out.println("Waiting for data...");

        while (true){
            System.out.println("Polling");
            ConsumerRecords<String, String> records = kafkaConsumer.poll(10000);
          //  ConsumerRecords<String, User> records1 = kafkaConsumer1.poll(100);

            for (ConsumerRecord<String, String> record : records){
            	 ConsumerRecord<String, String> customer = record;
                System.out.println(customer.value());
            }
            
           /* for (ConsumerRecord<String, User> record : records1){
            	User customer = record.value();
                System.out.println(customer);
            }*/

            kafkaConsumer.commitSync();
        }
    }
}
