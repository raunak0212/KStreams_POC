package com.bmo.ET.kafka.apps.v1;

import com.example.Customer;
import com.example.SmartCoreAPIService;
import com.example.avro.RawClass;


import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

public class KafkaAvroJavaProducerV1Demo {

    public static void main(String[] args) {
        Properties properties = new Properties();
        // normal producer
        properties.setProperty("bootstrap.servers", "127.0.0.1:9092");
        properties.setProperty("acks", "all");
        properties.setProperty("retries", "10");
        // avro part
        properties.setProperty("key.serializer", StringSerializer.class.getName());
        properties.setProperty("value.serializer", StringSerializer.class.getName());
        properties.setProperty("schema.registry.url", "http://127.0.0.1:8081");
        
        String value="{\"name\": \"Barack Obama\", \"age\": \"16\", \"isMarried\": \"false\", \"hobbies\": [\"Football\", \"Cricket\"]}";

        KafkaProducer<String, String> producer = new KafkaProducer<String, String>(properties);

        String topic = "input_topic4";
        List<String> hobbies=Arrays.asList("Football","Cricket");
        /*List<kids_record> li =new ArrayList();
        li.add(new kids_record("Billy","5"));*/
        RawClass rawClass = RawClass.newBuilder()
                .setName("Ellena Adams")
                .setAge("16")
                .setIsMarried("false")
                .setHobbies(hobbies)
               
                .build();

        ProducerRecord<String, String> producerRecord = new ProducerRecord<String, String>(
                topic, value
        );

        System.out.println(value);
        producer.send(producerRecord, new Callback() {
            @Override
            public void onCompletion(RecordMetadata metadata, Exception exception) {
                if (exception == null) {
                    System.out.println(metadata);
                } else {
                    exception.printStackTrace();
                }
            }
        });

        producer.flush();
        //producer.close();

    }
}
